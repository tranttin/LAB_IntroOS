/**
 * schedule_fcfs.c
 *
 * Schedule is in the format
 *
 *  [name] [priority] [CPU burst]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "task.h"
#include "cpu.h"
#include "schedulers.h"

#define SIZE    100


static int i=0;
Task task[SIZE];
// add a task to the list 
void add(char *name, int priority, int arrival, int burst) {
    task[i].name = name;
    task[i].burst = burst;
    i++;
}

// invoke the scheduler
void schedule(){
    int j=0;
    int time=0;
    for(j=0 ; j < i ; j++) {
        run(&task[j],time,task[j].burst);
        time += task[j].burst;
    }
}
